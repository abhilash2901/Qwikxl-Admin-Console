<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Response;
use App\User;
use App\Role;
use App\Departments;
use DB;
use Session;
use App\Category;
use App\Product;
use App\Store;
use Hash;

class CustomerWebservice extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function customerLogin($email,$password) {
		
		$user = User::where('email',$email)->get();
		
		if(count($user)==1){
			
			if (Hash::check($password, $user[0]->password)) {
                
                $data = array("status"=>'Login Successful','Mobile'=>$user[0]->contactnumber);
            } else {
               $data = array("status"=>'Login failed');
            }
		}else{
			$data = array("status"=>'Login failed');
		}
		print_r(json_encode($data));



	} 
}
