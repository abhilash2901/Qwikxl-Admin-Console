<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use App\User;
use App\Role;
use App\Store;
use App\Category;
use App\Departments;
use DB;
use Session;
use Hash;
class SubCate
    {
        
        public function getCategories($id,$type){
			

            $categories=\App\Category::where('parent_id',0)->where("store_id", $id)->where("type", $type)->get();//united

            $categories=$this->addRelation($categories);

            return $categories;

        } public function getCategoriesedit($ids,$id,$type){
			

            $categories=\App\Category::where('parent_id',0)->where("store_id", $ids)->where('id', '!=', $id)->where("type", $type)->get();//united

            $categories=$this->addRelation($categories);

            return $categories;

        }public function getCategorieslist($ids){
			

            $categories=\App\Category::where('parent_id',0)->where("store_id", $ids)->get();//united

            $categories=$this->addRelation($categories);

            return $categories;

        }

        protected function selectChild($id)
        {
			$ids = Session::get('store_userid');
            $categories=\App\Category::where('parent_id',$id)->get(); //rooney

            $categories=$this->addRelation($categories);

            return $categories;

        }

        protected function addRelation($categories){

            $categories->map(function ($item, $key) {
                
                $sub=$this->selectChild($item->id); 
                
                return $item=array_add($item,'subCategory',$sub);

            });

            return $categories;
        }
    }
class Categorys extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function index() {
        $ids = Session::get('store_userid');
         
        $categories = Category::where("store_id", $ids)->where("type", "1")->get();
        $categoriesnon = Category::where("store_id", $ids)->where("type", "0")->get();
        $dept = DB::table('departments')->where('store_id', '=', $ids)->get();
		$subcate=new SubCate;
        
        try {

            $allSubCategories=$subcate->getCategories($ids,1);
              $categoriesnon = $subcate->getCategories($ids,0);
        } catch (Exception $e) {
            
            //no parent category found
        }
        

        return view('storeuser.category', ['dept' => $dept,'allSubCategories' => $allSubCategories, 'categories' => $categories, 'categoriesnon' => $categoriesnon])->with('categories', $categories);
    }

    public function categorylist() {
        $ids = Session::get('store_userid');
        //$categories = Category::where("store_id", $ids)->get();
       $subcate=new SubCate;
        try {

            $categories=$subcate->getCategorieslist($ids);
              
        } catch (Exception $e) {
            
            //no parent category found
        }

        return view('storeuser.categorylist', ['categories' => $categories]);
    }

    public function editcategory($id) {
        //$input = $request->all();
        //var_dump($id);
        $ids = Session::get('store_userid');
		$subcate=new SubCate;
		try {

            $categories=$subcate->getCategoriesedit($ids,$id,1);
            $categoriesnon = $subcate->getCategoriesedit($ids,$id,0);
        } catch (Exception $e) {
            
            //no parent category found
        }

       // $categories = Category::where("store_id", $ids)->where('id', '!=', $id)->where("type", "1")->get();
        //$categoriesnon = Category::where("store_id", $ids)->where("type", "0")->get();
        $dept = DB::table('departments')->where('store_id', '=', $ids)->get();
        $data = Category::find($id);
        return view('storeuser.editcategory', ['dept' => $dept, 'data' => $data, 'categories' => $categories, 'categoriesnon' => $categoriesnon])->with('categories', $categories);
    }

    public function editscategorylist(Request $request) {
        // $input = $request->all();
        $input = Input::except(['_method', '_token']);
        $input['store_id'] = Session::get('store_userid');
        $id = $input['id'];
        Category::where("id", $id)->update($input);
        print_r(json_encode(array('status' => 'success', 'msg' => 'Store Updated Succesfully')));
    }

    public function deletecategory(Request $request) {
        $input = $request->all();
        $categories = Category::where("parent_id", $input['id'])->get();

        if (count($categories) > 0) {
            print_r(json_encode(array('status' => 'Failed', 'msg' => 'Parent Exist Please Delete The parent')));
        } else {
            Category::where('id', $input)->delete();
            print_r(json_encode(array('status' => 'success', 'msg' => 'Deleted Succesfully')));
        }
    }

    public function addcategory(Request $request) {
        $input = $request->all();
		
        $id = Session::get('id');
		
		
        $user = User::find($id);
        $input['store_id'] = $user->store_id;
        $create = Category::create($input);
        print_r(json_encode(array('status' => 'success', 'msg' => 'Category Created Succesfully')));
    }

    public function liststoreuser(Request $request) {
        $id = Session::get('id');
        $user = User::find($id);
        $users = Store::find($user->store_id);
        $list = DB::table('users')
                ->join('role_user', 'users.id', '=', 'role_user.user_id')
                ->join('roles', 'roles.id', '=', 'role_user.role_id')
                ->select('users.*', 'roles.display_name', 'roles.id as role_id ')
                ->where('users.store_id', $user->store_id)
                ->get();
        print_r(json_encode(array('users' => $users, 'storeuser' => $list)));
    }

    public function liststoresuser(Request $request) {
        $id = $request->id;
        $user = User::where("store_id", $id);
        //$users = Store::find($user->store_id);
        print_r(json_encode($user));
    }

    public function editstoredata(Request $request) {
        $input = $request->all();

        $id = $input['id'];
        Store::where("id", $id)->update($input);

        //$item = Item::find($id);
        print_r(json_encode(array('status' => 'success', 'msg' => 'Store Updated Succesfully')));
    }

    public function selectcategory(Request $request) {
        $input = $request->all();

        $id = $input['id'];
        $categories = Category::where("departments_id", $id)->get();

        print_r(json_encode($categories));
    }

}
